from django.apps import AppConfig


class LegalTextConfig(AppConfig):
    name = 'paint.legaltext'
